
from .clima_anom import prenetcdf,preprocess,mixture,metrics,geo
